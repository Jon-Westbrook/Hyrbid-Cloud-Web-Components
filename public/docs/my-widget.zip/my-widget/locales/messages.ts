import { defineMessages } from 'react-intl';

// This contains all the translatable interface messages.
const messages = defineMessages({
  greeting: { defaultMessage: 'Greeting', id: 'TvLEtg' },
});

export default messages;
